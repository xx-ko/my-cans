package xyc.sjxy.servlet;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class ServletConfig02 extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ServletConfig servletConfig02 = this.getServletConfig();
        //这个servletConfig对象是由servlet容器即tomvat的类实例 也即是说它是由容器给封装了配置文件信息一个对象
        //servletConfig = org.apache.catalina.core.StandardWrapperFacade@733315b6
        System.out.println("servletConfig02 = " + servletConfig02);
        System.out.println("servletConfig02.getServletName() = " + servletConfig02.getServletName());
        //ServletConfig02.getServletName() = servletConfig02
        //读取另外一个servlet的配置信息---读不到
        String encoding = servletConfig02.getInitParameter("encoding");
        String userName = servletConfig02.getInitParameter("userName");
        String userpwd = servletConfig02.getInitParameter("userPwd");
        System.out.println("encoding = " + encoding);
        System.out.println("userName = " + userName);
        System.out.println("userpwd = " + userpwd);
        //读取servlet配置的初始化参数
/*
        String encoding02 = servletConfig02.getInitParameter("encoding02");
        String userName02 = servletConfig02.getInitParameter("userName02");
        String userpwd02 = servletConfig02.getInitParameter("userPwd02");
        System.out.println("encoding02 = " + encoding02);
        System.out.println("userName02 = " + userName02);
        System.out.println("userpwd02 = " + userpwd02);
*/

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doGet(req, resp);
    }
}
