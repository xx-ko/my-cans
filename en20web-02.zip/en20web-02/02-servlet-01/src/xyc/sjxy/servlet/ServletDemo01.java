package xyc.sjxy.servlet;

import javax.servlet.*;
import java.io.IOException;

/**
 * 定义一个servlet 它可以处理http请求
 * 它必须要实现Servlet这个接口
 */
public class ServletDemo01 implements Servlet {
    @Override
    public void init(ServletConfig servletConfig) throws ServletException {

        //这个servlet初始化时执行的方法，这个方法在整个servet的生命周期中只会执行一次
        //即当这个servlet创建时执行
        System.out.println("\"servlet init\" = " + "servlet init");
    }

    @Override
    public ServletConfig getServletConfig() {
        return null;
    }

    @Override
    public void service(ServletRequest servletRequest, ServletResponse servletResponse) throws ServletException, IOException {
//这是sevlet的核心 方法，它就是用来处理servlet htttp请求的 所以程序员的业务 处理代码 就写在这里 如登录验证代码 等
        //这个 方法执行的次数和请求的次数 相关
        //http处理
        System.out.println("\"servlet service\" = " + "servlet service");
    }

    @Override
    public String getServletInfo() {
        return null;
    }

    @Override
    public void destroy() {
//这个方法是当servlet生命结束 时执行，也只会执行一次
        System.out.println("\"sevlet destroy\" = " + "sevlet destroy");
    }
}
