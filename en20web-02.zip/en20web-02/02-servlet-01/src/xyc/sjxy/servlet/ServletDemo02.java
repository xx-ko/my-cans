package xyc.sjxy.servlet;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import java.io.IOException;

public class ServletDemo02 extends GenericServlet {
    @Override
    public void service(ServletRequest servletRequest, ServletResponse servletResponse) throws ServletException, IOException {
        //servlet处理业务代码 写这里
        System.out.println("\"genericServlet service\" = " + "genericServlet service");

        //这个处理方法不能区分get还是post请求 put delete

        // doGet()
        // doPost()
        // doPut()
        // doDelete()
    }
}
