package xyc.sjxy.servlet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

@WebServlet("/jdbc")
public class JdbcServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //读取web应用下的资源配置文件：jdbc.properties
        ServletContext servletContext = this.getServletContext();
        Properties jdbcProp = new Properties();
        //不能用绝对路径 ，要用相对路径
        //InputStream in=new FileInputStream("E:\\zjl\\en20web-02\\02-servlet-01\\web\\configconfig/jdbc.propertiest");
        //root=E:\zjl\en20web-02\out\artifacts\02_servlet_01_Web_exploded
        String root=servletContext.getRealPath("/");
        System.out.println("root = " + root);
        //realPath=E:\zjl\en20web-02\out\artifacts\02_servlet_01_Web_exploded\config/jdbc.propertiest
        String realPath=servletContext.getRealPath("/config/jdbc.properties");
        InputStream in=new FileInputStream(realPath);
        jdbcProp.load(in);
        /*jdbcProp.forEach(new BiConsumer<Object, Object>() {  //匿名类的写法
            @Override
            public void accept(Object k, Object v) {
                System.out.println("k = " + k +"v="+ v);
            }
        });*/
        //用lambda表达式来代替
        jdbcProp.forEach((k,v)->System.out.println(k+"="+v));

        //动态获取web应用的布署路径,也即是web应用的根路径或叫虚拟目录：如：/02 或 /03等
        System.out.println("servletContext.getContextPath() = " + servletContext.getContextPath());

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req,resp);
    }
}
