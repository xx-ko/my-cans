package xyc.sjxy.servlet;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class ServletConfig01 extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ServletConfig servletConfig = this.getServletConfig();
        //这个servletConfig对象是由servlet容器即tomvat的类实例 也即是说它是由容器给封装了配置文件信息一个对象
        //servletConfig = org.apache.catalina.core.StandardWrapperFacade@733315b6
        System.out.println("servletConfig = " + servletConfig);
        System.out.println("servletConfig.getServletName() = " + servletConfig.getServletName());
        //servletConfig.getServletName() = servletConfig
        //读取servlet配置的初始化参数
        String encoding = servletConfig.getInitParameter("encoding");
        String userName = servletConfig.getInitParameter("userName");
        String userpwd = servletConfig.getInitParameter("userPwd");
        System.out.println("encoding = " + encoding);
        System.out.println("userName = " + userName);
        System.out.println("userpwd = " + userpwd);

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doGet(req, resp);
    }
}
