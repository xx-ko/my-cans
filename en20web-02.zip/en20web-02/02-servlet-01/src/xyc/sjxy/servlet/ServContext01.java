package xyc.sjxy.servlet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(value="/context01",initParams = @WebInitParam(name="appName",value="学生管理系统")) //servlet3.0以后才支持
//@WebServlet("/context01") //servlet3.0以后才支持
public class ServContext01 extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //打印sevletContext这个对象实例
        //ServletContext 这个接口有一个实现是tomcat提供的
        ServletContext servletContext = this.getServletContext();
        //servletContext = org.apache.catalina.core.ApplicationContextFacade@13f76616
        System.out.println("servletContext = " + servletContext);
        String encoding = servletContext.getInitParameter("encoding");
        String appName = this.getServletConfig().getInitParameter("appName");
        System.out.println("encoding = " + encoding);
        System.out.println("appName = " + appName);

        //设置一个k-v对 由另一个servlet来读取 这里要用到域对象;
        servletContext.setAttribute("userName","张三");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        this.doGet(req,resp);
    }
}
