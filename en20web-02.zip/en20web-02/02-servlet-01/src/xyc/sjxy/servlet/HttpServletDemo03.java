package xyc.sjxy.servlet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class HttpServletDemo03 extends HttpServlet {
    private String username;
    //javase： 封装 继承 多态

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //处理get请求
        username = req.getParameter("userName");
        String userPwd = req.getParameter("userPwd");
        if (username.equals("admin") && userPwd.equals("123")) {
            //
            System.out.println("登录成功");
        }else
        {
            System.out.println("登录失败");
        }
        //System.out.println("\"get 请求\" = " + "get 请求");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //处理post请求 增加操作
        //System.out.println("\"post 请求\" = " + "post 请求");
        this.doGet(req,resp);
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //处理put请求 修改
        //super.doPut(req, resp);
        System.out.println("\"doput\" = " + "doput");
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ///处理delete请求 删除
        //super.doDelete(req, resp);
        System.out.println("\"doDelete\" = " + "doDelete");
    }
}
