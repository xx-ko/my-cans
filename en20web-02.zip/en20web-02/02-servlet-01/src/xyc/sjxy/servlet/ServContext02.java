package xyc.sjxy.servlet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(value="/context02") //servlet3.0以后才支持
//@WebServlet("/context02") //servlet3.0以后才支持
public class ServContext02 extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //打印sevletContext这个对象实例
        //ServletContext 这个接口有一个实现是tomcat提供的 一个web应用只有一个servletContext对象
        ServletContext servletContext02 = this.getServletContext();
        //servletContext = org.apache.catalina.core.ApplicationContextFacade@13f76616
        //servletContext02 = org.apache.catalina.core.ApplicationContextFacade@13f76616
        System.out.println("servletContext02 = " + servletContext02);

        //读取web应用的全局初始化参数
        String encoding = servletContext02.getInitParameter("encoding");
        System.out.println("encoding = " + encoding);
        //读取sevletContext域中的k-v对：key：userName value：张三
        Object userName = servletContext02.getAttribute("userName");
        System.out.println("userName = " + userName);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        this.doGet(req,resp);
    }
}
