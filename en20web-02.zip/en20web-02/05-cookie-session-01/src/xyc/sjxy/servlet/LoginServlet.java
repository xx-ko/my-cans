package xyc.sjxy.servlet;

import xyc.sjxy.pojo.Users;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/login")  //处理登录请求
public class LoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //当登录成功转发SuccessServlet中，同时在面页上显示登录用户的名称
        String userName = req.getParameter("userName");
        String userPwd = req.getParameter("userPwd");
        if (userName.equals("admin") && userPwd.equals("123")) {

            //保存用户信息到session中
            Users user = new Users();
            user.setLoginPwd(userPwd);
            user.setLoginName(userName);
            req.getSession().setAttribute("loginInfo",user);
            req.getRequestDispatcher("/success").forward(req, resp);
        } else {
            //登录失败 重定向到errorServlet中
            req.getRequestDispatcher("/error").forward(req, resp);
        }

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
