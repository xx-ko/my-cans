package xyc.sjxy.servlet;

import xyc.sjxy.pojo.Users;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/list")
public class ListServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //这个servlet请求前要验证身份 也即是要先登录没有登录不允许访问
        //问题是怎么判断是否登录了？
        Users loginInfo = (Users) req.getSession().getAttribute("loginInfo");
        if (loginInfo!=null) {
            //表示已登录
            req.getRequestDispatcher("/success").forward(req, resp);
        }else{
            //没有登录 重定向到errorServlet
            req.getRequestDispatcher("/error").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req,resp);
    }
}
