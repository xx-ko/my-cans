package xyc.sjxy.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/c01")
public class CookieServlet01 extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        resp.setContentType("text/html;charset=utf-8");
        //创建一个cookie
        Cookie userName = new Cookie("username", "tom");
        Cookie userpwd = new Cookie("userpwd", "123");
        //cookie = javax.servlet.http.Cookie@6ae292a1  ///Object类的toSring方法
        // System.out.println("cookie = " + userName);
        //将cookie信息发送到浏览器端 以响应头的形式：Set-cookie:username=tom;userpwd=123
        resp.addCookie(userName);  //默认服务器发送给浏览器cookie信息是存入在浏览器的进程中(内存中)所以只能临时保存 一旦关闭cookie就没有了
        resp.addCookie(userpwd);  //如果 要永久保存cookie的话，必须将cookie存放在浏览器端的硬盘中 要实现这个功能 cookie设置一个属性MaxAge
        //这个属性的默认值 是-1（它代表存放在内存中）  用户只要设置 一个正数即可，如果 设置为0 代表删除cookie
        //当浏览器以后再次请求这个servlet时 它将前面保存的cookie以请求头的形式回送给服务器：Cookie:username=tom;userpwd=123

        //获取cookie信息
        Cookie[] cookies = req.getCookies();
        if (cookies!=null) {
            for (Cookie cookie : cookies) {
                String name = cookie.getName();  //key
                String value = cookie.getValue(); // value
               resp.getWriter().println(name+"="+value);
            }
        }else
        {
            resp.getWriter().println("没有任何cookie信息");
        }


    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        this.doGet(req,resp);
    }
}
