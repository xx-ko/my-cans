package xyc.sjxy.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet("/d")
public class CookieAccess extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html;charset=utf-8");
        PrintWriter out= resp.getWriter();
        //显示用户上次访问本网站的日期
        //读取cookie信息
        Cookie[] cookies = req.getCookies();
        boolean isFirst=true;
        Cookie  accessTime=null;
        if (cookies!=null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().contains("access")) {
                    //不是第一次访问
                    accessTime=cookie;
                    isFirst=false;
                    break;
                }
            }

        }else{
           isFirst=true;
        }
        if (isFirst) {
            //是第一次访问
            //这是第一次访问本网站 将当前 的访问时间记录到cookie中 且永久保存在硬盘
            Date date = new Date();
            SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String format = sd.format(date);//格式 化以后的时间
            //由于cookie中不能包含特殊字符如空格等  所以要编码
            format= URLEncoder.encode(format,String.valueOf(StandardCharsets.UTF_8));
            Cookie access = new Cookie("access", format);
            access.setMaxAge(3*60);  //保存3分钟
            resp.addCookie(access);//将访问存放到浏览器端
            out.println("你是第一次来到本网站!!");
        }else{
            //不是第一次访问
            //说明用户以前访问过本网站
            //读取cookie并显示在页面上
            String value = accessTime.getValue();
            //由于cookie编码过了，这次要解码
            value= URLDecoder.decode(value,String.valueOf(StandardCharsets.UTF_8));
            out.println("上次访问时间为："+value);
            //更新 cookie将当前的访问时间写回cookie中
            Date date = new Date();
            SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String format = sd.format(date);//格式化以后的时间
            format= URLEncoder.encode(format,String.valueOf(StandardCharsets.UTF_8));
            accessTime.setValue(format); //更新cookie的值
            //重新发回给浏览器
            accessTime.setMaxAge(3*60);
            resp.addCookie(accessTime);
        }

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doGet(req,resp);
    }
}
