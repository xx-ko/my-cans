package xyc.sjxy.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/s01")
public class SessionServlet01 extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取session对象\
        //1、先会去容器中获取session，如果能获取到，则用获取到的session,如果没有则创建一个新的session,同时会产生一个id--》sessionId(唯一的),然后返回
        HttpSession session=req.getSession();
        //2、先会去容器中获取session，如果能获取到，则用获取到的session,如果没有则不会创建一个新的session
        //HttpSession session=req.getSession(false); //req.getSession()---req.getSession(true)
        System.out.println("session = " + session);
        //session生成时会向浏览器发送一个cookie ：JSESSIONID=2A5252DE656305B4CF9637D6DDE94432; Path=/05; HttpOnly
        //后面再次请求时：只要session没有过期，就用原来的sessionId,浏览器会将原来保存的sessionId回送给服务器，以请求头Cookie的形式：
       // cookie:JSESSIONID=4694969029A6F492C5E2B7B6FB2BF133

        //session用来给不同请求共享资源 存放在session域中
        session.setAttribute("loginName","admin"); //将key-value对象存入到session中

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doGet(req,resp);
    }
}
