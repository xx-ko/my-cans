package xyc.sjxy.servlet;

import javax.servlet.http.HttpServlet;

public class AddServlet extends HttpServlet {
}
