package xyc.sjxy.pojo;

public class City {
    private String cId;
    private String cName;

    //private Province province;

    public City() {

    }

    public City(String cId, String cName) {
        this.cId = cId;
        this.cName = cName;
    }

    public String getcId() {
        return cId;
    }

    public void setcId(String cId) {
        this.cId = cId;
    }

    public String getcName() {
        return cName;
    }

    public void setcName(String cName) {
        this.cName = cName;
    }

    @Override
    public String toString() {
        return "City{" +
                "cId='" + cId + '\'' +
                ", cName='" + cName + '\'' +
                '}';
    }
}
