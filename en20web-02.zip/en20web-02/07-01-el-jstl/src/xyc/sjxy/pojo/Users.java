package xyc.sjxy.pojo;

/**
 * javaBean 实际上 就是一个普通的java类--》pojo
 */
public class Users {
    private long id;
    private String name;
    private String pwd;
    private boolean sex;
    private int age;
    private String hobby;

    private City city;

    /*public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }*/

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public String getHobby() {
        return hobby;
    }

    public void setHobby(String hobby) {
        this.hobby = hobby;
    }

    public long getId1() {  //属性id1的get访问器
        return id;
    }

    public void setId1(long id) { //属性id1的set访问器
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public boolean isSex() {   //属性sex的get访问器，只是访问器名称叫is
        return sex;
    }

    public void setSex(boolean sex) { //属性sex的set访问器
        this.sex = sex;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Users{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", pwd='" + pwd + '\'' +
                ", sex=" + sex +
                ", age=" + age +
                ", hobby='" + hobby + '\'' +
                ", city=" + city +
                '}';
    }
}
