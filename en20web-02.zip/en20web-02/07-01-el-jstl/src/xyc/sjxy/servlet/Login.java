package xyc.sjxy.servlet;

import org.apache.commons.beanutils.BeanUtils;
import xyc.sjxy.pojo.LoginInfo;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

@WebServlet("/login")
public class Login extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取用户的帐号和密码
        Map<String, String[]> map = req.getParameterMap();
        LoginInfo loginInfo = new LoginInfo();

        try {
            BeanUtils.populate(loginInfo, map);
            loginInfo.setLoginName("张三");
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        if (loginInfo.getLoginId().equals("admin") &&
                loginInfo.getLoginPwd().equals("123")) {
            //将登录成功的用户信息存入到session域
            req.getSession().setAttribute("loginInfo", loginInfo);
            //重定向到首页:index.jsp
            resp.sendRedirect(req.getContextPath() + "/index.jsp");
        }else{
            //登录失败 请求转发到页面：/jsp/error.jsp  且在页面上显示“用户帐号或密码错误"
            req.setAttribute("msg","用户帐号或密码错误<a href="+req.getContextPath()+"/jsp/login.jsp>请重新登录</a>");
            req.getRequestDispatcher("/jsp/error.jsp").forward(req,resp);
        }
    }
}
