package xyc.sjxy.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@WebServlet("/list")
public class List01 extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //定义一个数组Citys
        String[] citys = new String[]{
                "新余", "南昌", "九江", "吉安", "上饶", "赣州"
        };
        //创建一个集合
        List<String> list=new ArrayList<String>(Arrays.asList(citys));
        //将这个list集合存入到application域中
        req.getServletContext().setAttribute("list",list);
        //重定向到页面:list.jsp
        resp.sendRedirect(req.getContextPath()+"/jsp/list.jsp");

        //list.get(0)  //list[0]

    }
}
