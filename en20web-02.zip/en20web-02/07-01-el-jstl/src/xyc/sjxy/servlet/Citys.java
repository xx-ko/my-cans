package xyc.sjxy.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/city")
public class Citys extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //定义一个数组Citys
        String[] citys = new String[]{
                "新余", "南昌", "九江", "吉安", "上饶", "赣州"
        };
        //将citys存入到request域中
        req.setAttribute("citys",citys);

        //请求转发到jsp/array.jsp
        req.getRequestDispatcher("/jsp/array.jsp").forward(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
