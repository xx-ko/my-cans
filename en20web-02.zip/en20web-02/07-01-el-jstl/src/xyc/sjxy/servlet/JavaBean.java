package xyc.sjxy.servlet;

import xyc.sjxy.pojo.City;
import xyc.sjxy.pojo.Users;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/bean01")
public class JavaBean extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //创建一个javaBean，然后存入到四大域：page，request，session,application
        //这里选择session域
        Users user = new Users();  //为个user就是一个简单的javaBean
        user.setId1(1001);
        user.setName("张三");
        user.setPwd("123");
        user.setSex(true);
        user.setAge(20);
        user.setHobby("运动,音乐,编程");

        //添加 这个对象的city属性

        user.setCity(new City("0502","新余"));

        //将上面javaBean存入到session域
        req.getSession().setAttribute("user",user);
        //重定向到页面:/jsp/javaBean.jsp
        resp.sendRedirect(req.getContextPath()+"/jsp/javabean.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req,resp);
    }
}
