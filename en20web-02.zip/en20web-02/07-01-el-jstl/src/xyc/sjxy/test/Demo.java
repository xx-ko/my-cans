package xyc.sjxy.test;

import org.apache.commons.beanutils.BeanUtils;
import org.junit.Test;
import xyc.sjxy.pojo.Users;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

public class Demo {
    /*public static void main(String[] args) {

    }*/
    //用junit来进行单元测试
    @Test
    public void test01(){
        //测试javaBean
        Users user = new Users();  //为个user就是一个简单的javaBean
        user.setId1(1001);
        user.setName("张三");
        user.setPwd("123");
        user.setSex(true);
        user.setAge(20);
        System.out.println("user = " + user);
    }
    @Test
    public void test02() throws InvocationTargetException, IllegalAccessException {
        //测试javaBean
        Users user = new Users();  //为个user就是一个简单的javaBean
        BeanUtils.setProperty(user,"id1",1001);
        BeanUtils.setProperty(user,"name","张三");
        BeanUtils.setProperty(user,"sex",true);
        BeanUtils.setProperty(user,"age",20);
        System.out.println("user = " + user);
    }
    @Test
    public void test03() throws InvocationTargetException, IllegalAccessException {
        //测试javaBean
        Users user = new Users();  //为个user就是一个简单的javaBean
        Map map = new HashMap();
        map.put("id",1001);//map中key名称一定和javaBean中属性名一致，否则 赋值不会成功
        map.put("name","张三");
        map.put("pwd","123");
        map.put("sex",true);
        map.put("age",20);
        BeanUtils.populate(user,map);//给bean对象 user中属性赋值（通过map，但map中key名称一定和javaBean中属性名一致）
        System.out.println("user = " + user);
    }
}
