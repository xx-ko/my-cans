package xyc.sjxy.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/resp01")
public class HttpResponse  extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        //resp是一个servlet容器--tomcat来提供实例化
        //resp = org.apache.catalina.connector.ResponseFacade@18451dda  --这个类是由tomcat容器提供的
        System.out.println("resp = " + resp);
        //1、向浏览器发送响应码
        //resp.setStatus(404);

        //resp.setStatus(302); // 告诉浏览器要转向---》内部 或者 网站的外部
        //2、向浏览器发响应头信息
       // resp.setHeader("location","http://www.xyc.edu.cn");  //重定向到百度网站

        //以下这个方法可以代替上面两条语句
        //resp.sendRedirect("https://www.baidu.com");// 站外跳转
        //站内跳转
        //resp.setStatus(302);
        //由于重定向是浏览器的行为，而浏览器会将 “/" 解析为tomcat服务器地址，即：localhost:8080
        //所以要加上web应用的发布目录--虚拟目录  即/03--/03/success.html--->localhost:8080/03/success.html

        //但又不能硬编码，所以动态获取当前web应用的根即 /03  用servletContext.getContextPath() API
       // resp.setHeader("location",this.getServletContext().getContextPath()+"/success.html");

      //  resp.sendRedirect(this.getServletContext().getContextPath()+"/success.html");


        //3、向浏览器发送响应体---也即是发送响应消息
        //1)获取响应器 字节响应器 或者是 字符响应器
        //resp.getOutputStream().print("abcd");
        //resp.setCharacterEncoding("utf-8");
        //resp.getOutputStream().write("新余学院".getBytes(StandardCharsets.UTF_8));  //以字节流（二进制编码）的形式发送给浏览器

        //注：字节流响应器和字符流响应器不能同时用 一次只能用其中一个
        //resp.setContentType("text/html;charset=utf-8");  //这条语句一定放在servlet获取响应器之前，否则不会生效 还是乱码
        resp.setContentType("application/json;charset=utf-8");
        PrintWriter writer = resp.getWriter();
        //writer.write("新余学院<br/>");  //以字符流的形式发送给浏览器

        //向浏览器发送json格式的信息
        String user="{\"name\":\"张三\",\"age\":30,\"sex\":\"男\",\"depart\":{\"id\":1001,\"name\":\"数计学院\"}}"; //标准的json信息的键要用双引号包起来

        writer.write(user);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        this.doGet(req,resp);
    }
}
