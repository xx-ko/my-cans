package xyc.sjxy;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

@WebServlet("/code")
public class CheckCodeServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //生成验证码--它是一个图片
        //1、创建一个内存图片
        int width = 60;
        int height = 30;
        BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB); //生成一个内存图片

        //2、图片修饰
        //2.1填充背景
        Graphics g = img.getGraphics();//获取画板
        g.setColor(new Color(219, 210, 254));
        g.fillRect(0, 0, width, height);

        //2.1在图片上写验证码
        g.setColor(new Color(255, 255, 255));
        g.setFont(new Font("微软雅黑", Font.BOLD | Font.ITALIC|Font.TYPE1_FONT, 16));
        String numbers = "123456789abcdefg";
        StringBuilder sb = new StringBuilder();
        //String sb1 = new String();
        Random rd = new Random();//随机生成器
        int index = rd.nextInt(15);//产生[0,15]的随机整数
        char ch = numbers.charAt(index);//随机取一个数
        g.drawString(ch + "", 3, 17);//将数字写入到图片上
        sb.append(ch);

        index = rd.nextInt(15);//产生[0,15]的随机整数
        ch = numbers.charAt(index);//随机取一个数
        g.drawString(ch + "", 17, 22);//将数字写入到图片上
        sb.append(ch);

        index = rd.nextInt(15);//产生[0,5]的随机整数
        ch = numbers.charAt(index);//随机取一个数
        g.drawString(ch + "", 31, 18);//将数字写入到图片上
        sb.append(ch);

        index = rd.nextInt(15);//产生[0,15]的随机整数
        ch = numbers.charAt(index);//随机取一个数
        g.drawString(ch + "", 47, 15);//将数字写入到图片上
        sb.append(ch);
        //将验证码存入到session (保存同一个会话的任意请求都 可以去读取)
        HttpSession session = req.getSession();
        session.setAttribute("code",sb.toString()); //将验证码存入到session

        //3、将图片响应给浏览器
        ServletOutputStream out = resp.getOutputStream();  // 字节码响应器
        System.out.println("out = " + out);//out==org.apache.catalina.connector.CoyoteOutputStream
        ImageIO.write(img, "jpeg", out);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
