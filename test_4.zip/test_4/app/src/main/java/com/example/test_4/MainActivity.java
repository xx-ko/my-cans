package com.example.myapplication;
import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;
public class TwoActivity extends Activity {
    private EditText userName;
    private EditText userPwd;
    private EditText Name; 
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.two);
        userName = (EditText) findViewById(R.id.userName);
        userPwd = (EditText) findViewById(R.id.userPwd);
        Name=(EditText) findViewById(R.id.Name);
        userName.setText(getIntent().getStringExtra("userName"));
        userPwd.setText(getIntent().getStringExtra("userPwd"));
        Name.setText(getIntent().getStringExtra("Name"));
    }
}