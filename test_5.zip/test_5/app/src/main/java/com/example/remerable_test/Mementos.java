package com.example.remerable_test;

import android.net.Uri;
import android.provider.BaseColumns;

public class Mementos {
	public static final String AUTHORITY = "com.example.remerable_test.providers.memento";

	public static final class Memento implements BaseColumns {
		public static final String _ID = "_id";//memento_tb设定_id字段
		public static final String SUBJECT = "subject";//memento_tb设置subject字段
		public static final String BODY = "body";//memento_tb设置bodyt字段
		public static final String DATE = "date";//memento_tb设置date字段
		public static final Uri MEMENTOS_CONTENT_URI= Uri.parse("content://"
				+ AUTHORITY + "/mementos");//设置操作mementos的URI
		public static final Uri MEMENTO_CONTENT_URI= Uri.parse("content://"
				+ AUTHORITY + "/memento");//设置操作单个mementoURI
	}
}
