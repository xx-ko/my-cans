package com.example.test_2;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity implements Runnable {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_1);
    }

    private int colors[]=new int[]{0xFFFF0000,0xFF00FF00,0xFFFF00FF,0xFF00FFFF,0xFF0000FF

    };
    private int[] nextColorPointers=new int[]{
            1,2,3,4,0
    };
    private View views[];
    private int currentColor=0;
    private Handler handler;
    public  void run(){
        int nextColorPointer=currentColor;
        for(int i=views.length-1;i>=0;i--){
            views[i].setBackgroundColor(colors[nextColorPointers[nextColorPointer]]);//
            nextColorPointer=(++nextColorPointer)%5;
        }
        if(currentColor==4){
            currentColor=0;
        }else{
            currentColor++;
        }
        handler.postDelayed(this, 300);
    }
}
